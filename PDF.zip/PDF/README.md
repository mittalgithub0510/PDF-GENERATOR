# PDF Generator

A Java application that converts Text, Excel, and PowerPoint files to PDF format using a simple GUI.

## Features
- **Text to PDF**: Convert plain text files to PDF
- **Excel to PDF**: Convert Excel spreadsheets (.xls, .xlsx) to PDF
- **PowerPoint to PDF**: Convert PowerPoint presentations (.ppt, .pptx) to PDF

## Prerequisites
- **Java 21** (already installed ✓)
- **Apache Maven** (needs to be installed)

## Quick Start

### Option 1: Automatic Setup (Recommended)
Run the setup script that will install Maven automatically:
```batch
setup-and-run.bat
```

### Option 2: Manual Maven Installation
1. Download Maven from: https://maven.apache.org/download.cgi
2. Extract to a directory (e.g., `C:\Program Files\Apache\Maven`)
3. Add Maven's `bin` directory to your System PATH
4. Verify installation: `mvn -version`
5. Run the application: `RUN.bat`

### Option 3: Using Command Line
If Maven is already installed:
```batch
mvn clean compile
mvn exec:java
```

## Project Structure
```
PDF/
├── src/
│   ├── ConverterGUI.java    # Main GUI application
│   ├── TextToPDF.java       # Text to PDF converter
│   ├── ExcelToPDF.java      # Excel to PDF converter
│   └── PPTToPDF.java        # PowerPoint to PDF converter
├── pom.xml                  # Maven configuration
├── setup-and-run.bat        # Automatic setup script
└── RUN.bat                  # Quick run script
```

## How to Use
1. Run the application using one of the methods above
2. Click "Browse" to select your file
3. Click the appropriate conversion button:
   - **Text → PDF** for .txt files
   - **Excel → PDF** for .xls/.xlsx files
   - **PPT → PDF** for .ppt/.pptx files
4. The converted PDF will be saved in the same directory as the input file

## Dependencies
- Apache PDFBox 2.0.29 (PDF generation)
- Apache POI 5.2.5 (Excel and PowerPoint processing)

## Troubleshooting

### "Maven is not recognized"
- Maven is not installed or not in PATH
- Run `setup-and-run.bat` for automatic installation
- Or install manually following Option 2 above

### Build Errors
- Ensure Java 21 is installed: `java -version`
- Delete the `target` folder and rebuild: `mvn clean compile`

### Conversion Errors
- Ensure the input file is not corrupted
- Check that the file format matches the conversion button clicked
- For Excel files, ensure they're not password-protected

## Technical Details
- **Java Version**: 21
- **Build Tool**: Maven 3.x
- **GUI Framework**: Java Swing
- **PDF Library**: Apache PDFBox
- **Office Processing**: Apache POI
